<?php ?>
 <footer>
        <nav class="navbar navbar-dark bg-dark fixed-bottom">
            <a class="navbar-brand" href="index.php">
                <img id="icono" src="img/iconos/logotipo.svg"/>
            </a>
            <a class="navbar-brand" href="https://es-es.facebook.com/">
                <img id="icono" src="img/iconos/facebook.png"/>
            </a>
            <a class="navbar-brand" href="https://www.instagram.com/?hl=es">
                <img id="icono" src="img/iconos/instagram.png"/>
            </a>
        </nav>
    </footer>
