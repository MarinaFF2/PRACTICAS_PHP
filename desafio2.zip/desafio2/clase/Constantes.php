<?php
/**
 * Description of Constantes
 * @author Marina Flores Fernandez
 */
class Constantes {
    /**
     * Variables
     */
    public static $BBDD="desafio2";
    public static $usuario="marina";
    public static $password="Chubaca2019";
}